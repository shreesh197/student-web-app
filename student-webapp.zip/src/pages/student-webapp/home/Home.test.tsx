import { render, screen } from "@testing-library/react";
import HomePage from ".";

describe("Components renders properly", () => {
  test("HomePage renders properly", () => {
    //render(<HomePage />);
    //const heading = screen.getByText("This is Home Page");
    //expect(heading).toBeInTheDocument();
  });
});
