import Home from "../../../components/home";
// import './index.css';

const HomePage = () => {
    return <Home />
}

export default HomePage;