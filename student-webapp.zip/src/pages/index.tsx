import LoginPage from "./student-webapp/login";

const HomePage = () => {
  return <LoginPage />;
};
export default HomePage;
