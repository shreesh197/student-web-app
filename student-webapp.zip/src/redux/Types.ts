export interface StoreState {
    counter: number
}