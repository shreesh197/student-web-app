import { DeviceContext } from "app-repo-common-pkg";
import { useContext } from "react";
import { useForm } from "react-hook-form";
import { getCapitalizedString, getValidationErrMsg } from "../../../helper";

const TextField = ({
  value,
  labelText,
  onChange,
  placeholder,
  additionalClassName,
}: {
  value: string;
  labelText: string;
  onChange: any;
  placeholder: string;
  additionalClassName: string;
}) => {
  const { isMobile, isTab }: any = useContext(DeviceContext);
  const { register } = useForm({
    criteriaMode: "all",
  });
  return (
    <div className="text-fields">
      <span className="profile-label">{labelText}</span>
      <input
        value={value}
        className={`profile-input ${
          additionalClassName ? additionalClassName : ""
        }`}
        placeholder={placeholder}
        type={"text"}
        onChange={onChange}
      />
    </div>
  );
};

export default TextField;
